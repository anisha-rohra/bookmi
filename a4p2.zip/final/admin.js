var express = require('express');
var router = express.Router();
var async = require('async');
var pg = require('pg');
var bcrypt = require('bcryptjs');

router.use(function checkAdmin(req, res, next) {
	res.locals.session = req.session;
	if (req.session.admin === true || req.path == '/') {
		next();
	} else {
		// TODO enhance this
		// res.render('admin/signin.html');
    req.session.redirect = "/admin" + req.url;
    res.redirect('/');
  }
});

router.get('/signin', function (req, res) {
	res.render('admin/signin.html', {title: 'Bookmi Administrator'});
});

router.post('/signin', function (req, res) {
  // Use pg prepared query to prevent sql injection
  var username = [req.body.username];
  var query = 'SELECT * FROM "Users" WHERE "username" = $1;';
  client.query(query, username, function (err, qres) {
    if (err) {
      return console.log("error running query", err);
    } else if (qres.rows.length === 1 && bcrypt.compareSync(req.body.password, qres.rows[0].password)) {
    // Successful sign in - save session data
    req.session.username = qres.rows[0].username;
    req.session.admin = qres.rows[0].user_type === "admin";
    req.session.errors = [];
    res.redirect('/admin/');
    console.log(req.session.admin);
  } else {
    res.render("admin/signin.html", {
      error: "Username or password is not correct",
      title: "Bookmi Admininistration"});
  }
});
});

// Admin pages
// Main admin page
router.get('/analytics', function (req, res) {
	var users_count = 0;
	var exc_count = 0;
	var cmt_count = 0;
	var fol_count = 0;
	var own_count = 0;
	var wish_count = 0;
  var recent_users;
  var recent_reviews;
  async.parallel([
      //Load user counts
      function(callback) {
      	client.query('SELECT COUNT(*) FROM "Users";', function(err, result) {
      		if (err) {
      			console.log(err);
      			err_msg = "Database error, please try again later.";
      		} else {
      			user_count = result.rows[0].count;
      		}
      		callback();
      	});
      },
      //Load book exchange counts
      function(callback) {
      	client.query('SELECT COUNT(*) FROM "Exchanges";', function(err, result) {
      		if (err) {
      			console.log(err);
      			err_msg = "Database error, please try again later.";
      		} else {
      			exc_count = result.rows[0].count;
      		}
      		callback();
      	});
      },
      //Load comment counts
      function(callback) {
      	client.query('SELECT COUNT(*) FROM "Comments";', function(err, result) {
      		if (err) {
      			console.log(err);
      			err_msg = "Database error, please try again later.";
      		} else {
      			cmt_count = result.rows[0].count;
      		}
      		callback();
      	});
      },
      //Load owned counts
      function(callback) {
      	client.query('SELECT COUNT(*) FROM "Owns";', function(err, result) {
      		if (err) {
      			console.log(err);
      			err_msg = "Database error, please try again later.";
      		} else {
      			own_count = result.rows[0].count;
      		}
      		callback();
      	});
      },
      //Load wish counts
      function(callback) {
      	client.query('SELECT COUNT(*) FROM "Wishes";', function(err, result) {
      		if (err) {
      			console.log(err);
      			err_msg = "Database error, please try again later.";
      		} else {
      			wish_count = result.rows[0].count;
      		}
      		callback();
      	});
      },
      //Load follow counts
      function(callback) {
      	client.query('SELECT COUNT(*) FROM "Follows";', function(err, result) {
      		if (err) {
      			console.log(err);
      			err_msg = "Database error, please try again later.";
      		} else {
      			fol_count = result.rows[0].count;
      		}
      		callback();
      	});
      },
      // Get most recent users
      function(callback) {
        client.query('SELECT "username","created","id" FROM "Users" ORDER BY "created" DESC LIMIT 10;', function(err, result) {
          if (err) {
            console.log(err);
            err_msg = "Database error, please try again later.";
          } else {
            recent_users = result.rows;
          }
          callback();
        });
      },
      // Get most recent reviews join user join book
      function(callback) {
        client.query('SELECT * FROM "Comments" LEFT JOIN "Users" ON "Comments".user="Users".id ORDER BY "Comments".comment_date DESC LIMIT 10;', function(err, result) {
          //SELECT "Comments".user,"Comments".book,"Comments".comment_date,"Comments".message,"User.username" FROM "Comments" LEFT JOIN "Users".id="Comments".user;
          // ORDER BY "Comments".comment_date DESC LIMIT 10
          if (err) {
            console.log(err);
            err_msg = "Database error, please try again later.";
          } else {
            recent_reviews = result.rows;
          }
          callback();
        });
      },
  ], function(err) { //This function gets called after the two tasks have called their "task callbacks"
  if (err) throw err;
  res.render('admin/analytics.html', {title: 'Bookmi Administrator', 'users': user_count, exchanged: exc_count,
  	comments: cmt_count, follows: fol_count, wishes: wish_count, owns: own_count, 'reviews': recent_reviews,
    'r_users': recent_users});
});
});


// User search admin
router.get('/users', function (req, res) {
  // Default vars if not set
  var page = parseInt(req.query.p);
  var per_page = 10;
  if (req.query.num != undefined) {per_page = req.query.num;} // Get number of items to display
  if (per_page > 50) {per_page = 50;} // Limit to 50

  // Make sure page is a number > 0
  if (isNaN(page) || page < 0) {
  	page = 0;
  }

  // Using async to make sure queries are finished before processing
  var qresults;
  async.parallel([
    function (callback) {
      // Search for username
      if (req.query.search) {
        var search = '%' + req.query.search + '%'
        client.query('SELECT * FROM "Users" WHERE username ILIKE $1 OR email ILIKE $1 OR firstname ILIKE $1 OR lastname ILIKE $1 or location ILIKE $1 ORDER BY id LIMIT $2 OFFSET $3;', [search, per_page, page * per_page], function (err, qres) {
          if (err) {
            console.log("Database select error: " + err);
          } else {
            qresults = qres.rows;
          }
          callback();
        });
      } else {
        // Get all usernames
        client.query('SELECT * FROM "Users" ORDER BY id ASC LIMIT $1 OFFSET $2', [per_page, page * per_page], function (err, qres) {
          if (err) {
            return console.log("Database select error: " + err);
          } else {
            qresults = qres.rows;
          }
          callback();
        });
      };
    }], function(err, results) {
    if (!qresults) {
      res.redirect('/admin/users');
    }
    // Process results
    if (qresults.length >= 0) {
      for (var i = 0; i < qresults.length; i++) {
        // Trim date manually for now
        qresults[i].created = '' + qresults[i].created;
        if (qresults[i].created.length > 15) {
          qresults[i].created = qresults[i].created.substring(0, 15);
        }
      }
      // Figure out next and prev pages...
      var next_p;
      var prev_p;
      if (qresults.length < per_page) {
        next_p = 0;
      } else {
        next_p = page + 1;
      }
      prev_p =  page - 1;
      page += 1;
      res.render("admin/users.html",
        {title: "User Management",
        users: qresults,
        next: next_p,
        prev: prev_p
      });
    } else {
      res.redirect('/admin'); // Shouldn't reach here
    }
  });
});

// User search admin
router.get('/edit-user', function (req, res) {
      // Kick user back to user if no id specified
      if (req.query.id === undefined) {
      	res.redirect('/admin/users');
      	return;
      }

      var uid = req.query.id;
      client.query('SELECT * FROM "Users" WHERE "id" = $1;', [uid], function (err, qres) {
      	if (err) {
      		console.log("error running query", err);
          res.render("admin/invalid_user.html", {'id': uid});
      	} else if (qres.rows.length === 1) {
      		var u = qres.rows[0];
      		res.render("admin/edit-user.html",
      			{title: "Edit profile: " + qres.rows[0].username,
      			user: {
      				id: u.id,
      				username: u.username,
      				firstname: u.firstname,
      				lastname: u.lastname,
      				email: u.email,
      				age: u.age,
      				gender: u.gender,
      				location: u.location,
      				utype: u.user_type,
      				profile_pic: u.profile_pic
      			}
      		});
      	} else {
          res.render("admin/invalid_user.html", {'id': uid});
      	}
      });
    });

// User profile edit
router.post('/edit-user', function (req, res) {
      // Kick user back to user if no id specified
      if (req.query.id === undefined) {
      	res.redirect('/admin/users');
      	return;
      } else {
      	var uid = req.query.id;
      }
      // Check id
      if (req.body.user_id != uid) {
      	res.render('/admin/error.html', { err: "There was an error with the data submitted."});
      	return;
      }

      // Query db and check
      client.query('SELECT * FROM "Users" WHERE "id" = $1;', [uid], function (err, qres) {
      	if (err || qres.rows.length != 1) {
      		res.render("admin/users.html", { err: "There was an error with the database." });
      		return console.log("error running query", err);
        } else if (qres.rows[0].username != req.body.username ) { // Check if username matches
        	res.render("admin/users.html", { err: "There was an error with the database." });
        	return;
        } else {
          // Delete the user if checked
          if (req.body.delete != undefined) {
            client.query('DELETE FROM "Users" WHERE "id" = $1;', [uid], function (err) {
              res.redirect('/admin/users');
            });
            return;
          }

          // Need to validate some info - gender
          var gender = qres.rows[0].gender;
          if (req.body.gender == '-' || req.body.gender == 'm' || req.body.gender == 'f') {
          	gender = req.body.gender;
          }

          // Verify age
          var age = req.body.age;
          if (!/^\d+/.test(age)) { age = qres.rows[0].age; }

          // Verify email
          var email = req.body.email;
          if (!/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/.test(email)) {
          	email = qres.rows[0].email;
          }

          // Validate the user type
          var utype = req.body.utype;
          if (req.body.utype != "admin" && req.body.utype != "user") {
          	utype = qres.rows[0].user_type;
          }
          // Verify name
          var fname = req.body.first_name;
          if (fname.length == 0 ) {
            fname = qres.rows[0].firstname;
          }
          var lname = req.body.last_name;
          if (lname.length == 0 ) {
            lname = qres.rows[0].lastname;
          }

          // Change db now
          async.parallel([
            // Check password
            function(callback) {
            	if (req.body.password.length > 0) {
            		if (req.body.password != req.body.pwd_confirm) {
            			console.log("pwd doesn't match");
            			req.session.errors.push("Passwords did not match, please try again.");
            		} else {
                  // Change password
                  var hash = bcrypt.hashSync(req.body.password, 10);
                  client.query('UPDATE "Users" SET password=$1 WHERE id=$2', [hash, uid], function (err) {
                  	if (err) {
                  		req.session.errors.push("Database error, password not updated.");
                  		console.log("error changing password");
                  	}
                  });
                }
              }
              callback();
            },
            // Change email
            function(callback) {
            	// Check if email is the same, no need to change
            	if (email == qres.rows[0].email) {
            		callback();
            	} else {
            		client.query('SELECT * from "Users" WHERE "email"=$1', [email], function (err, qres_e) {
            			if (qres_e.rows.length) {
            				req.session.errors.push("New email already in use.");
            			} else {
            				client.query('UPDATE "Users" SET email=$1 WHERE id=$2', [email, uid], function (err) {
            					if (err) {
            						req.session.errors.push("Error updating database.");
            						console.log("Error updating database - email");
            					}
            					callback();
            				})
            			}
            		})
            	}
            },
            // Change everything else
            function(callback) {
            	client.query('UPDATE "Users" SET firstname=$1,lastname=$2,age=$3,gender=$4,location=$5,user_type=$6 WHERE id=$7',
            		[fname, lname, age, gender, req.body.location, utype, uid], function (err, qres_a) {
            			if (err) {
            				req.session.errors.push("Error updating database.");
            				console.log("Error updating database - aux info");
            			}
            			callback();
            		})
            },



            ], function(err) {
            	res.redirect('/admin/edit-user?id=' + uid);
            });

        }
      });
});

// Admin get comments
router.get('/reviews', function (req, res) {
  var page = parse_page(req);
  var per_page = parse_per_page(req);
  var qresults;
  async.parallel([
    function (callback) {
      // Search for username
      if (req.query.search) {
        var search = req.query.search;
        if (search.length > 30) {
          search = search.substring(0,30);
        }
        search = '%' + search + '%'
        client.query('SELECT "Comments".id,"Comments".book,"Comments".message,"Comments".rating,"Comments".comment_date,"Comments".user,"Users".username FROM "Comments" LEFT JOIN "Users" ON "Comments".user="Users".id WHERE "Users".username ILIKE $1 OR "Comments".message ILIKE $1 OR "Comments".book ILIKE $1 ORDER BY "Comments".comment_date DESC LIMIT $2 OFFSET $3 ;', [search, per_page, page * per_page], function (err, qres) {
          if (err) {
            console.log("Database select error: " + err);
            return res.redirect('/admin/reviews');
          } else {
            qresults = qres.rows;
          }
          callback();
        });
      } else {
        // Get all usernames
        client.query('SELECT "Comments".id,"Comments".book,"Comments".message,"Comments".rating,"Comments".comment_date,"Comments".user,"Users".username FROM "Comments" LEFT JOIN "Users" ON "Comments".user="Users".id ORDER BY "Comments".comment_date DESC LIMIT $1 OFFSET $2', [per_page, page * per_page], function (err, qres) {
          if (err) {
            console.log("Database select error: " + err);
            return res.redirect('/admin/reviews');
          } else {
            qresults = qres.rows;
          }
          callback();
        });
      };
    }], function(err, results) {
    // Process results
    if (qresults.length >= 0) {
      for (var i = 0; i < qresults.length; i++) {
        // Trim date manually for now
        qresults[i].comment_date = '' + qresults[i].comment_date;
        if (qresults[i].comment_date.length > 15) {
          qresults[i].comment_date = qresults[i].comment_date.substring(0, 15);
        }
      }
      // Figure out next and prev pages...
      var next_p;
      var prev_p;
      if (qresults.length < per_page) {
        next_p = 0;
      } else {
        next_p = page + 1;
      }
      prev_p =  page - 1;
      page += 1;
      res.render("admin/reviews.html",
        {title: "Bookmi Comments Management",
        comments: qresults,
        next: next_p,
        prev: prev_p
      });
    } else {
      res.redirect('/admin'); // Shouldn't reach here
    }
  });
});

// Delete reviews from database
router.delete('/reviews/:id', function (req, res) {
  client.query('DELETE FROM "Comments" WHERE "id"=$1;', [req.params.id], function(err, qres){
    if (err) {
      console.log("Database DELETE error.");
      console.log(err);
      return res.json({ 'success': false })
    } else {
      return res.json({ 'success': true })
    }
  })
});

// Admin delete comments


// Admin delete exch reviews

// router.delete('/')

// Parse request query to get page number
function parse_page (req) {
  var page = parseInt(req.query.p);
  if (isNaN(page) || page < 0) {  // Make sure page is a number > 0
    page = 0;
  }
  return page;
}

// Parse request query to get items per page
function parse_per_page (req) {
  var per_page = 10;
  if (req.query.num != undefined) {per_page = req.query.num;} // Get number of items to display
  if (per_page > 50) {per_page = 50;} // Limit to 50
  return per_page;
}

// Book search admin
router.get('/books', function (req, res) {
	res.render('admin/books.html', {title: 'Admin Book Search'});
});

// Default page
router.get('/', function (req, res) {
	res.redirect("/admin/users");
});

module.exports = router;
