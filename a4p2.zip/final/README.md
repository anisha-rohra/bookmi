Anisha Rohra, g5anisha, anisha.rohra@mail.utoronto.ca
Shannon Lui, g5shann, shannon.lui@mail.utoronto.ca
Nick Popovic, c2popovi, nicholas.popovic@mail.utoronto.ca
GongCheng Yao, c6yaogon, gc.yao@mail.utoronto.ca

BOOKMI README

SETTING UP ON LOCALHOST:
- call npm install in order to install all required module
- call node server.js in order to start the port
- access the site at localhost:3000

ON HEROKU:
https://bookmi.herokuapp.com/

GitHub: https://github.com/gcyao/a4
Username: Guest309
Password: summer1234

ADMIN ACCOUNTS:
username: admin
password: admin1

username: anisha
password: testing

username: shannon
password: testing

SAMPLE CLIENT ACCOUNTS:
username: tobeornottobe
password: testing

username: pikachu
password: testing

username: flowercrown
password: testing

username: mrdarcy
password: testing

Please use these accounts to view what a populated account what look like.

TROUBLESHOOTING:
Since the google API is being used, if while testing the code, many blanks start appearing where books should be, there will be many google keys at the top of the server.js code. If you would like, you can simple uncomment one of them while commenting out the one currently being used in order to get access to the API again.

HOW TO USE:

LOGIN / SIGNUP:
A user can log in using their username and password, or by logging in through google. Similarly, to sign up, either our local sign up system can be used or a user can sign up through Google.

RECOMMENDATIONS / FEED:
The user, upon logging in, is greeted with a recommendations page which will be updated regularly based on the users existing wish list. Under the recommendations section is a feed that updates the user with the most recent actions of the users they follow.

SEARCH BOOKS / BOOK PAGE:
A user can search for books in the search bar via its title or author and will be presented with a page containing several potential results. After finding the book they were looking for, they can add this book to either their swap list or their wish list, or they can review the book by clicking on the book's picture on the search page. By adding it to a list, that information is added to the book’s page so that other users can find people that either own the book or want the book.

REQUEST:
Users can request a swap by choosing a book on the other user's "want" list and a book on their "own" list. In doing so, this update that user’s requests section and informs them of a new request. Once the requested user accepts or rejects, the requester user is made aware of the response. If the response was affirmative, the users are asked to message one another to exchange swapping details.

RATING:
After the request has been completed, the users can optionally review the other user on their request experience through the Requests page, which updates that user's profile with the average rating and all the comments made for that user.
Books can also be reviewed by visiting the book's page. All reviews for that book already made are also displayed on the page.

USER PROFILING:
Each user has their own profile, created upon registration, that contains username and password information, alongside their primary emails and their individually created exchange/wish lists. Certain personal attributes are hidden from the public, visible only to the administrator and that individual user. Users can view basic information and exchange/wish lists of other users. If the user wants to search for a user, this can be done through the community tab, where all the users they are currently following as well as all the users that are following them is displayed. When viewing another user’s profile, they can see basic, nonprivate details, including name and follower count, as well as their exchange and wish lists. They can also make the requests for swapping on this profile page.

USER INTERACTIONS/ADMIN VIEW:
We have users or administrators. The users have limited capability as far as being able to view other users information, and cannot edit other users information at all. Administrators can view and edit all users’ information. They can also view the total number of exchanges and exchange rating/comments, and all reviews made on the books, and other useful analytics.

SOCIAL NETWORK:
Users can follow other users in order to keep track of their exchange and wish lists, as well as their reviews for books on the community section. They can also privately message them in order to arrange swap information or to discuss their mutual love of reading.
